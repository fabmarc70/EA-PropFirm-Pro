import { useState, useEffect } from "react";
import {
  AreaChart, Area, BarChart, Bar, ComposedChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, ReferenceLine, Cell
} from "recharts";

// MODELES FUNDEDNEXT - REGLES OFFICIELLES 2026 (Stellar)
const MODELS = {
  "2step": {
    name: "Stellar 2-Step",
    phases: [
      { label: "Phase 1", target: 0.08, minDays: 5 },
      { label: "Phase 2", target: 0.05, minDays: 5 },
    ],
    dailyDD: 0.05, totalDD: 0.10, challengeReward: 0.15, firstPayoutDays: 21,
  },
  "1step": {
    name: "Stellar 1-Step",
    phases: [{ label: "Phase unique", target: 0.10, minDays: 2 }],
    dailyDD: 0.03, totalDD: 0.06, challengeReward: 0.15, firstPayoutDays: 5,
  },
  "lite": {
    name: "Stellar Lite",
    phases: [
      { label: "Phase 1", target: 0.08, minDays: 5 },
      { label: "Phase 2", target: 0.04, minDays: 5 },
    ],
    dailyDD: 0.04, totalDD: 0.08, challengeReward: 0.15, firstPayoutDays: 21,
  },
};

// Frais d'achat approximatifs du challenge (ordre de grandeur, USD)
const FEES = { 6000: 59, 15000: 119, 25000: 199, 50000: 299, 100000: 549, 200000: 999 };
function challengeFee(capital) {
  const sizes = Object.keys(FEES).map(Number).sort((a, b) => a - b);
  let closest = sizes[0];
  for (const s of sizes) if (Math.abs(s - capital) < Math.abs(closest - capital)) closest = s;
  return FEES[closest];
}

const SIM_DAYS = 90;

const fmt = (v) => "$" + Number(v).toLocaleString("en-US", { maximumFractionDigits: 0 });
const fmt2 = (v) => "$" + Number(v).toLocaleString("en-US", { maximumFractionDigits: 2 });
const fmtPn = (v) => (v >= 0 ? "+" : "") + (v * 100).toFixed(2) + "%";

// ─── MOTEUR TRADE-PAR-TRADE AVEC CLUSTERING ───────────────────────────────────
// clustering 0 = trades independants. clustering eleve = series de pertes/gains plus longues.
// On utilise une chaine de Markov : apres une perte, la proba de reperdre augmente.
function makeTradeStream(winrate, clustering, maxConsecLosses) {
  const w = winrate / 100;
  let lastWin = Math.random() < w;
  let consecLosses = 0;
  const cap = (maxConsecLosses > 0 && maxConsecLosses < 100) ? maxConsecLosses : Infinity;

  return function nextTrade() {
    // CONTRAINTE DURE : forcer un gain apres N pertes consecutives
    if (consecLosses >= cap) {
      lastWin = true;
      consecLosses = 0;
      return true;
    }
    if (clustering <= 0) {
      lastWin = Math.random() < w;
    } else {
      const pull = clustering * 0.5;
      const adjW = lastWin
        ? w + (1 - w) * pull
        : w - w * pull;
      lastWin = Math.random() < Math.max(0.02, Math.min(0.98, adjW));
    }
    if (!lastWin) consecLosses++;
    else consecLosses = 0;
    return lastWin;
  };
}

// DD journalier verifie en INTRADAY (apres chaque trade), pas en fin de journee
function simulateDay(equity, tradesPerDay, riskAmount, rr, nextTrade, dailyDDLimit) {
  let dayEquity = equity;
  let dayLowPnl = 0; // pire perte cumulee intraday
  let wins = 0, losses = 0;
  for (let t = 0; t < tradesPerDay; t++) {
    const win = nextTrade();
    if (win) { dayEquity += riskAmount * rr; wins++; }
    else { dayEquity -= riskAmount; losses++; }
    const cumPnl = dayEquity - equity;
    if (cumPnl < dayLowPnl) dayLowPnl = cumPnl;
    // breach intraday
    if (-dayLowPnl > dailyDDLimit) {
      return { dayEquity, dayPnl: dayEquity - equity, wins, losses, breached: true };
    }
  }
  return { dayEquity, dayPnl: dayEquity - equity, wins, losses, breached: false };
}

function simulatePhase(capital, cfg, model, p) {
  const { target, minDays } = cfg;
  const dailyDDLimit = capital * model.dailyDD;
  const floorEquity = capital * (1 - model.totalDD);
  const riskAmount = capital * p.riskPct;
  const nextTrade = makeTradeStream(p.winrate, p.clustering, p.maxConsecLosses);
  let equity = capital;
  const days = [];
  let status = "running";
  let tradingDays = 0, totalWins = 0, totalLosses = 0, winDayCount = 0;
  let peak = capital;
  let maxDD = 0; // en % du capital initial

  for (let d = 1; d <= SIM_DAYS; d++) {
    const res = simulateDay(equity, p.tradesPerDay, riskAmount, p.rr, nextTrade, dailyDDLimit);
    totalWins += res.wins;
    totalLosses += res.losses;
    equity = res.dayEquity;
    if (equity > peak) peak = equity;
    const dd = (capital - equity) / capital; // DD depuis capital initial (regle FundedNext)
    if (dd > maxDD) maxDD = dd;

    if (res.breached) {
      status = "failed_daily_dd";
      days.push({ day: d, equity: +equity.toFixed(2), status: "fail" });
      break;
    }
    if (res.dayPnl >= 0) winDayCount++;

    if (equity < floorEquity) {
      status = "failed_total_dd";
      days.push({ day: d, equity: +equity.toFixed(2), status: "fail" });
      break;
    }

    tradingDays++;
    days.push({ day: d, equity: +equity.toFixed(2), status: "ok" });

    const profit = (equity - capital) / capital;
    if (profit >= target && tradingDays >= minDays) { status = "passed"; break; }
  }

  if (status === "running") status = "running_ok";
  const totalTrades = totalWins + totalLosses;
  return {
    days, finalEquity: equity, status, tradingDays,
    profit: (equity - capital) / capital,
    tradeWinrate: totalTrades > 0 ? (totalWins / totalTrades) * 100 : 0,
    dayWinrate: tradingDays > 0 ? (winDayCount / tradingDays) * 100 : 0,
    totalWins, totalLosses,
    maxDD: maxDD * 100, // en %
    maxDDAmount: maxDD * capital, // en $
  };
}

function simulateFunded(capital, months, model, p, split) {
  const dailyDDLimit = capital * model.dailyDD;
  const floorEquity = capital * (1 - model.totalDD);
  const riskAmount = capital * p.riskPct;
  const nextTrade = makeTradeStream(p.winrate, p.clustering, p.maxConsecLosses);
  let equity = capital;
  let currentCapital = capital; // capital de reference (augmente apres scaling)
  let cumulPayout = 0, pendingPayout = 0;
  const data = [];
  let status = "active", scalingCount = 0;
  let winMonths = 0, lossMonths = 0;
  const TD_MONTH = 21;
  let maxDD = 0;

  // PAYOUT REEL : bi-weekly = 14j ~ toutes les 2 semaines
  // On simule en mois (21 jours trading) = ~1.5 cycles de 14j par mois
  // Simplification : payout disponible 2x par mois si eligible
  const PAYOUT_MIN = 50; // seuil reel FundedNext ($50 hors USDT)
  const firstPayoutDone = false;
  let payoutCycleCount = 0; // nombre de cycles de payout effectues

  // SCALING REEL : 4 mois consecutifs profitables + 2 payouts minimum dans ces 4 mois
  let consecutiveProfitMonths = 0;
  let payoutsInStreak = 0;
  let currentSplit = split; // split evolue apres scaling (80% -> 90%)

  for (let m = 1; m <= months; m++) {
    const monthStart = equity;
    let monthFailed = null;

    for (let d = 0; d < TD_MONTH; d++) {
      const res = simulateDay(equity, p.tradesPerDay, riskAmount, p.rr, nextTrade, dailyDDLimit);
      equity = res.dayEquity;
      const dd = (currentCapital - equity) / currentCapital;
      if (dd > maxDD) maxDD = dd;
      if (res.breached) { monthFailed = "failed_daily_dd"; break; }
      if (equity < currentCapital * (1 - model.totalDD)) { monthFailed = "failed_total_dd"; break; }
    }

    const pnl = equity - monthStart;
    const profitable = pnl >= 0;
    if (profitable) winMonths++; else lossMonths++;

    // SUIVI STREAK pour scaling
    if (profitable) {
      consecutiveProfitMonths++;
    } else {
      consecutiveProfitMonths = 0;
      payoutsInStreak = 0;
    }

    // PAYOUT : bi-weekly = 2 opportunites par mois (14j chacune)
    // Seuil minimum reel = $50
    let payout = 0;
    if (pnl > 0) {
      pendingPayout += pnl * currentSplit;
      // 2 cycles de payout par mois (bi-weekly)
      for (let cycle = 0; cycle < 2; cycle++) {
        if (pendingPayout >= PAYOUT_MIN) {
          payout += pendingPayout;
          cumulPayout += pendingPayout;
          payoutCycleCount++;
          if (profitable) payoutsInStreak++;
          pendingPayout = 0;
        }
      }
      payout = +payout.toFixed(2);
    }

    // SCALING REEL : 4 mois consecutifs profitables + min 2 payouts dans ces 4 mois
    let scalingNote = null;
    if (consecutiveProfitMonths >= 4 && payoutsInStreak >= 2) {
      scalingCount++;
      const addedCapital = capital * 0.40; // +40% du capital INITIAL
      currentCapital = equity + addedCapital;
      equity = currentCapital; // le nouveau solde inclut le scaling
      currentSplit = Math.min(0.90, split + (0.10 * scalingCount)); // passe a 90% apres scale
      consecutiveProfitMonths = 0; // reset le compteur
      payoutsInStreak = 0;
      scalingNote = "Scale +" + fmt(addedCapital) + " -> Split " + Math.round(currentSplit * 100) + "%";
    }

    data.push({
      month: m,
      equity: +equity.toFixed(2),
      payout,
      cumul: +cumulPayout.toFixed(2),
      status: monthFailed ? "fail" : "active",
      profitPct: +((pnl / monthStart) * 100).toFixed(2),
      ddPct: +(Math.max(0, (currentCapital - equity) / currentCapital * 100)).toFixed(2),
      scalingNote,
      currentSplit: Math.round(currentSplit * 100),
      streakMonths: consecutiveProfitMonths,
    });

    if (monthFailed) { status = monthFailed; break; }
  }

  const totalM = winMonths + lossMonths;
  return {
    data, finalEquity: equity, cumulPayout,
    pendingPayout: +pendingPayout.toFixed(2),
    status, scalingCount,
    winrateMonth: totalM > 0 ? (winMonths / totalM) * 100 : 0,
    winMonths, lossMonths,
    maxDD: maxDD * 100,
    maxDDAmount: maxDD * currentCapital,
    finalSplit: Math.round(currentSplit * 100),
  };
}

export default function App() {
  const [modelKey, setModelKey] = useState("2step");
  const [capital, setCapital] = useState(25000);
  const [riskPct, setRiskPct] = useState(0.2);
  const [dailyTargetPct, setDailyTargetPct] = useState(0.25);
  const [winrate, setWinrate] = useState(55);
  const [tradesPerDay, setTradesPerDay] = useState(3);
  const [clusteringPct, setClusteringPct] = useState(40);
  const [maxConsecLosses, setMaxConsecLosses] = useState(4);
  const [split, setSplit] = useState(80);
  const [fundedMonths, setFundedMonths] = useState(12);
  const [tab, setTab] = useState("challenge");
  const [sim, setSim] = useState(null);
  const [seed, setSeed] = useState(0);
  const [copied, setCopied] = useState(false);

  const model = MODELS[modelKey];
  const risk = riskPct / 100;
  const dailyTarget = dailyTargetPct / 100;
  const splitRate = split / 100;
  const clustering = clusteringPct / 100;
  // maxConsecLosses deja en nombre entier
  const fee = challengeFee(capital);

  const w = winrate / 100;
  const requiredRR = w > 0 ? (dailyTarget / (tradesPerDay * risk) + (1 - w)) / w : 0;
  const rrValid = requiredRR > 0 && requiredRR < 20;
  const riskAmount = capital * risk;
  const monthlyTarget = dailyTarget * 21;

  const p = { tradesPerDay, riskPct: risk, rr: requiredRR, winrate, clustering, maxConsecLosses };

  useEffect(() => {
    if (!rrValid) { setSim(null); return; }
    const phaseResults = [];
    let allPassed = true;
    for (let i = 0; i < model.phases.length; i++) {
      if (!allPassed) { phaseResults.push(null); continue; }
      const r = simulatePhase(capital, model.phases[i], model, p);
      phaseResults.push(r);
      if (r.status !== "passed") allPassed = false;
    }
    const funded = allPassed ? simulateFunded(capital, fundedMonths, model, p, splitRate) : null;

    // Reward 15% du challenge : sur le profit cumule des phases passees
    let challengeReward = 0;
    if (allPassed) {
      phaseResults.forEach(ph => {
        if (ph && ph.profit > 0) challengeReward += capital * ph.profit * model.challengeReward;
      });
    }
    setSim({ phaseResults, funded, allPassed, challengeReward });
  }, [modelKey, capital, riskPct, dailyTargetPct, winrate, tradesPerDay, clusteringPct, maxConsecLosses, splitRate, fundedMonths, seed]);

  // Bilan financier net
  const netResult = () => {
    if (!sim) return null;
    const reward = sim.challengeReward || 0;
    const payout = sim.funded ? sim.funded.cumulPayout : 0;
    const pending = sim.funded ? sim.funded.pendingPayout : 0;
    const gross = reward + payout + pending;
    const net = gross - fee;
    return { reward, payout, pending, gross, fee, net };
  };
  const bilan = netResult();

  // Analyse DD config
  const ddAnalysis = () => {
    const maxDayLoss = tradesPerDay * riskAmount; // perte max en 1 jour
    const maxDayLossPct = (maxDayLoss / capital) * 100;
    const ddLimit = capital * model.totalDD;
    const dailyDDLimit = capital * model.dailyDD;
    // Jours consecutifs 100% perdants pour toucher le DD total
    const daysToTotalDD = Math.ceil(ddLimit / maxDayLoss);
    // Jours pour toucher le DD journalier (si possible)
    const canBreachDaily = maxDayLoss > dailyDDLimit;
    // DD actuel de cette simulation
    let simMaxDD = 0, simMaxDDAmount = 0;
    if (sim) {
      sim.phaseResults.forEach(ph => {
        if (ph && ph.maxDD > simMaxDD) { simMaxDD = ph.maxDD; simMaxDDAmount = ph.maxDDAmount; }
      });
      if (sim.funded && sim.funded.maxDD > simMaxDD) {
        simMaxDD = sim.funded.maxDD;
        simMaxDDAmount = sim.funded.maxDDAmount;
      }
    }
    const distancePct = model.totalDD * 100 - simMaxDD;
    const distanceAmt = capital * model.totalDD - simMaxDDAmount;
    return {
      maxDayLoss, maxDayLossPct, ddLimit, dailyDDLimit,
      daysToTotalDD, canBreachDaily,
      simMaxDD, simMaxDDAmount,
      distancePct, distanceAmt,
      safePct: 100 - (simMaxDD / (model.totalDD * 100)) * 100,
    };
  };
  const dda = ddAnalysis();

  const globalStatus = () => {
    if (!sim) return null;
    for (let i = 0; i < sim.phaseResults.length; i++) {
      const ph = sim.phaseResults[i];
      if (ph && ph.status.startsWith("failed"))
        return { label: "ECHEC - " + model.phases[i].label, color: "#ef4444", bg: "#2d0808", emoji: "ROUGE" };
      if (ph && ph.status === "running_ok")
        return { label: "EN COURS - " + model.phases[i].label, color: "#fbbf24", bg: "#2d1f08", emoji: "ORANGE" };
    }
    if (!sim.funded) return null;
    if (sim.funded.status.startsWith("failed"))
      return { label: "COMPTE FERME", color: "#ef4444", bg: "#2d0808", emoji: "ROUGE" };
    return { label: "COMPTE ACTIF", color: "#6ee7b7", bg: "#062318", emoji: "VERT" };
  };
  const gs = globalStatus();
  const dot = (e) => e === "VERT" ? "\u{1F7E2}" : e === "ORANGE" ? "\u{1F7E0}" : "\u{1F534}";

  const phaseIcon = (s) => {
    if (s === "passed") return { icon: "\u2713", color: "#6ee7b7", bg: "#062318", label: "PASSE" };
    if (s === "running_ok") return { icon: "~", color: "#fbbf24", bg: "#2d1f08", label: "EN COURS" };
    if (s && s.startsWith("failed")) return { icon: "\u2717", color: "#ef4444", bg: "#2d0808", label: "ECHOUE" };
    return { icon: "-", color: "#64748b", bg: "#111118", label: "N/A" };
  };
  const failReason = (s) => {
    if (s === "failed_daily_dd") return "DD journalier " + (model.dailyDD * 100) + "% depasse (intraday) - compte ferme";
    if (s === "failed_total_dd") return "DD total " + (model.totalDD * 100) + "% depasse - compte ferme";
    if (s === "running_ok") return "Objectif pas atteint apres 90j (pas de limite de temps - continue)";
    return null;
  };

  // ─── RAPPORT TEXTE (copie) ────────────────────────────────────────────────
  const buildReport = () => {
    if (!sim) return "RR invalide - ajuste winrate ou objectif";
    const sep = "─".repeat(48);
    let txt = "RAPPORT SIMULATION FUNDEDNEXT\n" + sep + "\n";
    txt += "Modele  : " + model.name + "\n";
    txt += "Date    : " + new Date().toLocaleDateString("fr-FR") + "\n";
    txt += "Statut  : " + (gs ? gs.label : "En cours") + "\n";
    txt += sep + "\n";
    txt += "PARAMETRES TRADING\n";
    txt += "Capital          : " + fmt(capital) + "\n";
    txt += "Risque/trade     : " + riskPct + "% = " + fmt2(riskAmount) + " (fixe)\n";
    txt += "Trades/jour      : " + tradesPerDay + "\n";
    txt += "Winrate          : " + winrate + "%\n";
    txt += "Clustering pertes: " + clusteringPct + "%\n";
    txt += "Objectif/jour    : " + dailyTargetPct + "%\n";
    txt += "RR necessaire    : 1:" + requiredRR.toFixed(2) + "\n";
    txt += "Profit/mois cible: " + (monthlyTarget * 100).toFixed(1) + "%\n";
    txt += sep + "\n";
    txt += "CHALLENGE\n";
    sim.phaseResults.forEach((ph, i) => {
      if (!ph) { txt += model.phases[i].label + " : verrouille\n"; return; }
      txt += model.phases[i].label + " (obj +" + (model.phases[i].target * 100) + "%)  : "
        + phaseIcon(ph.status).label
        + "  |  Profit " + fmtPn(ph.profit)
        + "  |  WR " + ph.tradeWinrate.toFixed(0) + "%"
        + "  |  " + ph.tradingDays + " jours\n";
    });
    txt += sep + "\n";
    if (sim.funded) {
      const f = sim.funded;
      txt += "COMPTE FUNDED (" + fundedMonths + " mois) - " + (f.status === "active" ? "ACTIF" : "FERME") + "\n";
      txt += "Capital final    : " + fmt(f.finalEquity) + "\n";
      txt += "Payout verse     : " + fmt2(f.cumulPayout) + "\n";
      txt += "En attente       : " + fmt2(f.pendingPayout) + "\n";
      txt += "WR mensuel       : " + f.winrateMonth.toFixed(0) + "%\n";
      txt += "Mois gagnants    : " + f.winMonths + "/" + (f.winMonths + f.lossMonths) + "\n";
      txt += sep + "\n";
      txt += "DETAIL MENSUEL\n";
      const COL = [6, 12, 10, 10, 8];
      const pad = (s, n) => String(s).padStart(n);
      txt += pad("Mois", COL[0]) + pad("Equity", COL[1]) + pad("Profit%", COL[2]) + pad("Payout", COL[3]) + pad("Statut", COL[4]) + "\n";
      txt += "-".repeat(COL.reduce((a, b) => a + b, 0)) + "\n";
      f.data.forEach(r => {
        txt += pad("M" + r.month, COL[0])
          + pad(fmt(r.equity), COL[1])
          + pad((r.profitPct >= 0 ? "+" : "") + r.profitPct.toFixed(2) + "%", COL[2])
          + pad(r.payout > 0 ? fmt(r.payout) : "-", COL[3])
          + pad(r.status === "active" ? "OK" : "FERME", COL[4]) + "\n";
      });
    } else {
      txt += "COMPTE FUNDED : challenge non passe\n";
    }
    txt += sep + "\n";
    if (bilan) {
      txt += "BILAN FINANCIER NET\n";
      txt += "Reward challenge 15%   : +" + fmt2(bilan.reward) + "\n";
      txt += "Payouts funded verses  : +" + fmt2(bilan.payout) + "\n";
      txt += "En attente (non verse) : +" + fmt2(bilan.pending) + "\n";
      txt += "Frais challenge        : -" + fmt2(bilan.fee) + "\n";
      txt += "─".repeat(32) + "\n";
      txt += "RESULTAT NET           :  " + fmt2(bilan.net) + "\n";
    }
    txt += sep + "\n";
    txt += "Simulation indicative - regles FundedNext 2026 - pas une garantie.\n";
    return txt;
  };

  // ─── EXPORT HTML pour impression (injecte dans le DOM, pas window.open) ───
  const buildHtml = () => {
    if (!sim) return null;
    const f = sim.funded;
    let rows = "";
    if (f) {
      f.data.forEach(r => {
        rows += "<tr>"
          + "<td>M" + r.month + "</td>"
          + "<td>" + fmt(r.equity) + "</td>"
          + "<td style='color:" + (r.profitPct >= 0 ? "#16a34a" : "#dc2626") + "'>"
          + (r.profitPct >= 0 ? "+" : "") + r.profitPct.toFixed(2) + "%</td>"
          + "<td style='color:" + (r.payout > 0 ? "#d97706" : "#9ca3af") + ";font-weight:" + (r.payout > 0 ? "700" : "400") + "'>"
          + (r.payout > 0 ? fmt(r.payout) : "-") + "</td>"
          + "<td style='color:" + (r.status === "active" ? "#16a34a" : "#dc2626") + ";font-weight:700'>"
          + (r.status === "active" ? "OK" : "FERME") + "</td>"
          + "</tr>";
      });
    }
    const bilanRows = bilan ? (
      "<tr><td>Reward challenge 15%</td><td style='color:#16a34a'>+" + fmt2(bilan.reward) + "</td></tr>"
      + "<tr><td>Payouts funded verses</td><td style='color:#16a34a'>+" + fmt2(bilan.payout) + "</td></tr>"
      + "<tr><td>En attente (non verse)</td><td style='color:#6b7280'>+" + fmt2(bilan.pending) + "</td></tr>"
      + "<tr><td>Frais challenge</td><td style='color:#dc2626'>-" + fmt2(bilan.fee) + "</td></tr>"
      + "<tr style='border-top:2px solid #000'><td><strong>RESULTAT NET</strong></td><td style='color:" + (bilan.net >= 0 ? "#16a34a" : "#dc2626") + ";font-size:16px;font-weight:800'>" + fmt2(bilan.net) + "</td></tr>"
    ) : "";
    return (
      "<html><head><meta charset='utf-8'><title>Rapport FundedNext</title>"
      + "<style>"
      + "body{font-family:Arial,sans-serif;padding:28px;color:#111;font-size:12px;line-height:1.6;}"
      + "h1{color:#0d9488;font-size:20px;margin-bottom:2px;}"
      + "h2{color:#0d9488;font-size:13px;margin-top:20px;border-bottom:2px solid #0d9488;padding-bottom:3px;text-transform:uppercase;}"
      + ".badge{display:inline-block;padding:3px 12px;border-radius:20px;font-weight:700;font-size:12px;margin:8px 0;}"
      + ".grid{display:flex;flex-wrap:wrap;gap:10px;margin:10px 0;}"
      + ".box{border:1px solid #ddd;border-radius:6px;padding:8px 12px;min-width:120px;}"
      + ".box .l{font-size:9px;color:#888;text-transform:uppercase;}"
      + ".box .v{font-size:15px;font-weight:800;margin-top:2px;}"
      + "table{width:100%;border-collapse:collapse;margin-top:8px;font-size:11px;}"
      + "th{background:#0d9488;color:#fff;padding:6px 8px;text-align:right;}"
      + "td{padding:5px 8px;border-bottom:1px solid #eee;text-align:right;}"
      + ".footer{margin-top:28px;font-size:9px;color:#aaa;text-align:center;}"
      + "@media print{body{padding:16px;}}"
      + "</style></head><body>"
      + "<h1>Rapport Simulation FundedNext</h1>"
      + "<div style='color:#666;font-size:11px;margin-bottom:6px'>" + new Date().toLocaleDateString("fr-FR") + " - " + model.name + " - Regles Stellar 2026</div>"
      + "<span class='badge' style='background:" + (gs ? gs.bg.replace("#", "#") : "#eee") + ";color:" + (gs ? gs.color : "#333") + ";border:1px solid " + (gs ? gs.color : "#ccc") + "'>" + (gs ? gs.label : "En cours") + "</span>"
      + "<h2>Parametres Trading</h2><div class='grid'>"
      + "<div class='box'><div class='l'>Capital</div><div class='v'>" + fmt(capital) + "</div></div>"
      + "<div class='box'><div class='l'>Risque/trade</div><div class='v'>" + riskPct + "% = " + fmt2(riskAmount) + "</div></div>"
      + "<div class='box'><div class='l'>Trades/jour</div><div class='v'>" + tradesPerDay + "</div></div>"
      + "<div class='box'><div class='l'>Winrate</div><div class='v'>" + winrate + "%</div></div>"
      + "<div class='box'><div class='l'>Clustering</div><div class='v'>" + clusteringPct + "%</div></div>"
      + "<div class='box'><div class='l'>Objectif/jour</div><div class='v'>" + dailyTargetPct + "%</div></div>"
      + "<div class='box'><div class='l'>RR necessaire</div><div class='v'>1:" + requiredRR.toFixed(2) + "</div></div>"
      + "<div class='box'><div class='l'>Profit/mois</div><div class='v'>" + (monthlyTarget * 100).toFixed(1) + "%</div></div>"
      + "</div>"
      + "<h2>Challenge</h2><div class='grid'>"
      + sim.phaseResults.map((ph, i) => ph
        ? "<div class='box'><div class='l'>" + model.phases[i].label + "</div><div class='v' style='color:" + phaseIcon(ph.status).color + "'>" + phaseIcon(ph.status).label + "</div><div style='font-size:10px;color:#666'>" + fmtPn(ph.profit) + " | WR " + ph.tradeWinrate.toFixed(0) + "% | " + ph.tradingDays + "j</div></div>"
        : "<div class='box'><div class='l'>" + model.phases[i].label + "</div><div class='v' style='color:#aaa'>N/A</div></div>"
      ).join("")
      + "</div>"
      + (f ? (
        "<h2>Compte Funded (" + fundedMonths + " mois)</h2><div class='grid'>"
        + "<div class='box'><div class='l'>Statut</div><div class='v' style='color:" + (f.status === "active" ? "#16a34a" : "#dc2626") + "'>" + (f.status === "active" ? "ACTIF" : "FERME") + "</div></div>"
        + "<div class='box'><div class='l'>Capital final</div><div class='v'>" + fmt(f.finalEquity) + "</div></div>"
        + "<div class='box'><div class='l'>Payout verse</div><div class='v' style='color:#d97706'>" + fmt2(f.cumulPayout) + "</div></div>"
        + "<div class='box'><div class='l'>En attente</div><div class='v' style='color:#6b7280'>" + fmt2(f.pendingPayout) + "</div></div>"
        + "<div class='box'><div class='l'>WR mensuel</div><div class='v'>" + f.winrateMonth.toFixed(0) + "%</div></div>"
        + "<div class='box'><div class='l'>Mois gagnants</div><div class='v'>" + f.winMonths + "/" + (f.winMonths + f.lossMonths) + "</div></div>"
        + "</div>"
        + "<h2>Detail Mensuel</h2>"
        + "<table><thead><tr><th>Mois</th><th>Equity</th><th>Profit %</th><th>Payout</th><th>Statut</th></tr></thead>"
        + "<tbody>" + rows + "</tbody></table>"
      ) : "<h2>Compte Funded</h2><p style='color:#dc2626'>Challenge non passe.</p>")
      + (bilan ? "<h2>Bilan Financier Net</h2><table style='max-width:320px'><tbody>" + bilanRows + "</tbody></table>" : "")
      + "<div class='footer'>Simulation indicative basee sur les regles FundedNext 2026. Pas une garantie financiere.</div>"
      + "</body></html>"
    );
  };

  const copyReport = () => {
    const txt = buildReport();
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(txt).then(
        () => { setCopied(true); setTimeout(() => setCopied(false), 2000); },
        () => fallbackCopy(txt));
    } else fallbackCopy(txt);
  };
  const fallbackCopy = (txt) => {
    const ta = document.createElement("textarea");
    ta.value = txt; ta.style.position = "fixed"; ta.style.opacity = "0";
    document.body.appendChild(ta); ta.select();
    try { document.execCommand("copy"); setCopied(true); setTimeout(() => setCopied(false), 2000); }
    catch (e) { alert("Copie impossible"); }
    document.body.removeChild(ta);
  };

  // IMPRESSION : injecte un iframe hidden dans le DOM actuel (contourne le sandbox)
  const printReport = () => {
    const html = buildHtml();
    if (!html) return;
    // Supprimer un eventuel iframe precedent
    const old = document.getElementById("print-frame");
    if (old) document.body.removeChild(old);
    const iframe = document.createElement("iframe");
    iframe.id = "print-frame";
    iframe.style.cssText = "position:fixed;width:0;height:0;border:none;left:-9999px;top:-9999px;";
    document.body.appendChild(iframe);
    const doc = iframe.contentWindow.document;
    doc.open(); doc.write(html); doc.close();
    iframe.contentWindow.focus();
    setTimeout(() => {
      iframe.contentWindow.print();
    }, 600);
  };

  const wrColor = winrate >= 60 ? "#6ee7b7" : winrate >= 50 ? "#fbbf24" : "#ef4444";
  const clColor = clusteringPct <= 25 ? "#6ee7b7" : clusteringPct <= 55 ? "#fbbf24" : "#ef4444";

  return (
    <div style={{ fontFamily: "system-ui, sans-serif", background: "#080810", minHeight: "100vh", color: "#e2e8f0", padding: "14px", maxWidth: 480, margin: "0 auto" }}>
      <style>{`
        * { box-sizing: border-box; }
        .card { background: #111118; border: 1px solid #1e1e2e; border-radius: 12px; padding: 14px; margin-bottom: 12px; }
        .tab-btn { padding: 7px 12px; border-radius: 8px; border: none; cursor: pointer; font-size: 11px; font-weight: 800; }
        .tab-btn.on { background: #6ee7b7; color: #080810; }
        .tab-btn.off { background: #111118; color: #64748b; border: 1px solid #1e1e2e; }
        .model-btn { flex: 1; padding: 9px 4px; border-radius: 8px; cursor: pointer; font-size: 10px; font-weight: 800; border: 1px solid #1e1e2e; }
        .model-btn.on { background: #6ee7b7; color: #080810; border-color: #6ee7b7; }
        .model-btn.off { background: #111118; color: #64748b; }
        input[type=range] { width: 100%; accent-color: #6ee7b7; margin-top: 3px; }
        input[type=number] { background: #080810; border: 1px solid #1e1e2e; border-radius: 6px; color: #e2e8f0; padding: 5px 8px; width: 100%; font-size: 13px; }
        .row { display: flex; justify-content: space-between; padding: 7px 0; border-bottom: 1px solid #1e1e2e; font-size: 12px; }
        .row:last-child { border-bottom: none; }
        .tag { display: inline-block; padding: 2px 10px; border-radius: 20px; font-size: 10px; font-weight: 800; }
        .kpi { background: #0a0a14; border-radius: 8px; padding: 10px; }
      `}</style>

      <div style={{ textAlign: "center", marginBottom: 14 }}>
        <div style={{ fontSize: 19, fontWeight: 800, color: "#6ee7b7" }}>FundedNext Simulator</div>
        <div style={{ fontSize: 10, color: "#475569", marginTop: 2 }}>Moteur trade-par-trade realiste - Stellar 2026</div>
      </div>

      {/* MODELE */}
      <div className="card">
        <div style={{ fontSize: 11, fontWeight: 800, color: "#6ee7b7", marginBottom: 8, textTransform: "uppercase", letterSpacing: 1 }}>Modele</div>
        <div style={{ display: "flex", gap: 6 }}>
          {Object.keys(MODELS).map(k => (
            <button key={k} className={"model-btn " + (modelKey === k ? "on" : "off")} onClick={() => setModelKey(k)}>
              {MODELS[k].name.replace("Stellar ", "")}
            </button>
          ))}
        </div>
        <div style={{ marginTop: 8, fontSize: 10, color: "#64748b", lineHeight: 1.5 }}>
          {model.phases.map(ph => ph.label + " " + (ph.target * 100) + "%").join(" / ")}
          {" - DD jour " + (model.dailyDD * 100) + "% - DD total " + (model.totalDD * 100) + "% - frais ~" + fmt(fee)}
        </div>
        {modelKey === "lite" && (
          <div style={{ marginTop: 8, background: "#2d0808", border: "1px solid #ef444440", borderRadius: 8, padding: "8px 10px", fontSize: 11, color: "#fca5a5", lineHeight: 1.5 }}>
            EA INTERDIT sur Stellar Lite CFD. Les EAs et indicateurs tiers sont strictement interdits — trading manuel uniquement. Utilise le 2-Step ou 1-Step pour ton EA.
          </div>
        )}
      </div>

      {/* STATUT */}
      {gs && (
        <div style={{ background: gs.bg, border: "1px solid " + gs.color + "30", borderRadius: 10, padding: "12px 16px", marginBottom: 12, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontSize: 15, fontWeight: 800, color: gs.color }}>{gs.label}</div>
            <div style={{ fontSize: 10, color: "#64748b", marginTop: 2 }}>
              {bilan ? "Resultat net : " + fmt2(bilan.net) : "Resultat challenge"}
            </div>
          </div>
          <div style={{ fontSize: 26 }}>{dot(gs.emoji)}</div>
        </div>
      )}

      {/* CARTE DRAWDOWN ESTIME */}
      {dda && (
        <div className="card" style={{ borderLeft: "3px solid " + (dda.simMaxDD < model.totalDD * 50 ? "#6ee7b7" : dda.simMaxDD < model.totalDD * 75 ? "#fbbf24" : "#ef4444") }}>
          <div style={{ fontSize: 11, fontWeight: 800, color: "#e2e8f0", marginBottom: 10, textTransform: "uppercase", letterSpacing: 1 }}>
            Analyse Drawdown - Ta config
          </div>

          {/* Jauge DD */}
          <div style={{ marginBottom: 12 }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, marginBottom: 4 }}>
              <span style={{ color: "#64748b" }}>DD atteint cette simulation</span>
              <span style={{ fontWeight: 800, color: dda.simMaxDD < model.totalDD * 100 * 0.5 ? "#6ee7b7" : dda.simMaxDD < model.totalDD * 100 * 0.75 ? "#fbbf24" : "#ef4444" }}>
                {dda.simMaxDD.toFixed(2)}% ({fmt2(dda.simMaxDDAmount)})
              </span>
            </div>
            <div style={{ background: "#1e1e2e", borderRadius: 8, height: 18, overflow: "hidden", position: "relative" }}>
              {/* Zone verte 0-50% de la limite */}
              <div style={{ position: "absolute", left: 0, top: 0, width: "50%", height: "100%", background: "#06231820", borderRight: "1px dashed #6ee7b730" }} />
              {/* Zone orange 50-80% */}
              <div style={{ position: "absolute", left: "50%", top: 0, width: "30%", height: "100%", background: "#2d1f0820", borderRight: "1px dashed #fbbf2430" }} />
              {/* Zone rouge 80-100% */}
              <div style={{ position: "absolute", left: "80%", top: 0, width: "20%", height: "100%", background: "#2d080820" }} />
              {/* Barre DD actuel */}
              <div style={{
                position: "absolute", left: 0, top: 0, height: "100%",
                width: Math.min(100, (dda.simMaxDD / (model.totalDD * 100)) * 100) + "%",
                background: dda.simMaxDD < model.totalDD * 100 * 0.5 ? "#6ee7b7" : dda.simMaxDD < model.totalDD * 100 * 0.75 ? "#fbbf24" : "#ef4444",
                borderRadius: 8, transition: "width 0.5s"
              }} />
              {/* Label limite */}
              <div style={{ position: "absolute", right: 4, top: 1, fontSize: 9, color: "#ef4444", fontWeight: 700 }}>
                {(model.totalDD * 100)}% = LIMITE
              </div>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 9, color: "#475569", marginTop: 2 }}>
              <span>0%</span>
              <span style={{ color: "#6ee7b7" }}>Zone safe</span>
              <span style={{ color: "#fbbf24" }}>Attention</span>
              <span style={{ color: "#ef4444" }}>Danger</span>
            </div>
          </div>

          {/* Stats */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            <div className="kpi">
              <div style={{ fontSize: 9, color: "#64748b" }}>Perte max 1 jour</div>
              <div style={{ fontSize: 14, fontWeight: 800, color: "#fbbf24" }}>{dda.maxDayLossPct.toFixed(2)}%</div>
              <div style={{ fontSize: 9, color: "#475569" }}>{fmt2(dda.maxDayLoss)}</div>
            </div>
            <div className="kpi">
              <div style={{ fontSize: 9, color: "#64748b" }}>Jours full-perte DD total</div>
              <div style={{ fontSize: 14, fontWeight: 800, color: "#ef4444" }}>{dda.daysToTotalDD}j</div>
              <div style={{ fontSize: 9, color: "#475569" }}>avant limite {(model.totalDD*100)}%</div>
            </div>
            <div className="kpi">
              <div style={{ fontSize: 9, color: "#64748b" }}>DD journalier franchissable</div>
              <div style={{ fontSize: 13, fontWeight: 800, color: dda.canBreachDaily ? "#ef4444" : "#6ee7b7" }}>
                {dda.canBreachDaily ? "OUI - RISQUE" : "NON - SAFE"}
              </div>
              <div style={{ fontSize: 9, color: "#475569" }}>
                {dda.canBreachDaily
                  ? "perte max " + dda.maxDayLossPct.toFixed(2) + "% > " + (model.dailyDD*100) + "%"
                  : "perte max " + dda.maxDayLossPct.toFixed(2) + "% < " + (model.dailyDD*100) + "%"}
              </div>
            </div>
            <div className="kpi">
              <div style={{ fontSize: 9, color: "#64748b" }}>Marge restante</div>
              <div style={{ fontSize: 14, fontWeight: 800, color: dda.distancePct > 5 ? "#6ee7b7" : "#ef4444" }}>
                {dda.distancePct > 0 ? dda.distancePct.toFixed(2) + "%" : "DEPASSE"}
              </div>
              <div style={{ fontSize: 9, color: "#475569" }}>{dda.distancePct > 0 ? fmt2(dda.distanceAmt) + " restants" : "compte ferme"}</div>
            </div>
          </div>

          <div style={{ marginTop: 10, background: "#0a0a14", borderRadius: 8, padding: "8px 10px", fontSize: 11, lineHeight: 1.5 }}>
            <span style={{ color: "#64748b" }}>Lecture : </span>
            {dda.canBreachDaily
              ? <span style={{ color: "#ef4444" }}>Attention - avec {tradesPerDay} trades a {riskPct}% tu peux declencher le DD journalier en 1 seule journee. Reduis le risque/trade ou le nombre de trades.</span>
              : <span style={{ color: "#6ee7b7" }}>Securise - le DD journalier {(model.dailyDD*100)}% est inatteignable en 1 jour avec ta config ({dda.maxDayLossPct.toFixed(2)}% max). Seule une accumulation sur {dda.daysToTotalDD}+ jours perdants peut te sortir.</span>
            }
          </div>
        </div>
      )}
      <div className="card" style={{ borderLeft: "3px solid " + wrColor }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 6 }}>
          <span style={{ fontSize: 11, fontWeight: 800, color: wrColor, textTransform: "uppercase", letterSpacing: 1 }}>Winrate global</span>
          <span style={{ fontSize: 24, fontWeight: 800, color: wrColor }}>{winrate}%</span>
        </div>
        <input type="range" min={30} max={90} step={1} value={winrate} onChange={e => setWinrate(parseInt(e.target.value))} />
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 9, color: "#475569", marginTop: 2 }}>
          <span>30%</span><span>60%</span><span>90%</span>
        </div>
        <div style={{ marginTop: 8, background: "#0a0a14", borderRadius: 8, padding: "8px 10px", fontSize: 11, color: rrValid ? "#93c5fd" : "#ef4444" }}>
          {rrValid
            ? <>RR necessaire : <b>1:{requiredRR.toFixed(2)}</b> (gain {fmt2(riskAmount * requiredRR)} / perte {fmt2(riskAmount)})</>
            : <>RR impossible ou &gt; 20 - winrate trop bas pour cet objectif.</>}
        </div>
      </div>

      {/* JAUGE CLUSTERING + MAX PERTES CONSECUTIVES */}
      <div className="card" style={{ borderLeft: "3px solid " + clColor }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 6 }}>
          <span style={{ fontSize: 11, fontWeight: 800, color: clColor, textTransform: "uppercase", letterSpacing: 1 }}>Clustering des pertes</span>
          <span style={{ fontSize: 24, fontWeight: 800, color: clColor }}>{clusteringPct}%</span>
        </div>
        <input type="range" min={0} max={100} step={5} value={clusteringPct} onChange={e => setClusteringPct(parseInt(e.target.value))} />
        <div style={{ marginTop: 8, fontSize: 10, color: "#64748b", lineHeight: 1.5 }}>
          0% = trades independants (theorique). Plus c'est haut, plus les pertes arrivent en
          <b style={{ color: clColor }}> series noires</b>. Recommande : 35-50%.
        </div>

        <div style={{ marginTop: 12, borderTop: "1px solid #1e1e2e", paddingTop: 10 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 6 }}>
            <span style={{ fontSize: 11, fontWeight: 800, color: "#6ee7b7", textTransform: "uppercase", letterSpacing: 1 }}>
              Max pertes consecutives EA
            </span>
            <span style={{ fontSize: 24, fontWeight: 800, color: "#6ee7b7" }}>{maxConsecLosses}</span>
          </div>
          <input type="range" min={1} max={20} step={1} value={maxConsecLosses} onChange={e => setMaxConsecLosses(parseInt(e.target.value))} style={{ accentColor: "#6ee7b7" }} />
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 9, color: "#475569", marginTop: 2 }}>
            <span>1</span><span>5</span><span>10</span><span>20</span>
          </div>
          <div style={{ marginTop: 8, background: "#062318", border: "1px solid #6ee7b730", borderRadius: 8, padding: "8px 10px", fontSize: 11, lineHeight: 1.6 }}>
            <div style={{ color: "#6ee7b7", fontWeight: 700, marginBottom: 4 }}>Avec ton EA (max {maxConsecLosses} pertes)</div>
            <div style={{ color: "#e2e8f0" }}>
              Perte max en serie : <b style={{ color: "#fbbf24" }}>{(maxConsecLosses * riskPct).toFixed(2)}%</b>
              {" = "}<b style={{ color: "#fbbf24" }}>{(maxConsecLosses * capital * risk).toFixed(0)}$</b>
            </div>
            <div style={{ color: "#e2e8f0" }}>
              Series pour atteindre DD 10% : <b style={{ color: "#ef4444" }}>
                {Math.ceil(capital * model.totalDD / (maxConsecLosses * capital * risk)).toFixed(0)} series perdantes
              </b> sans aucun gain
            </div>
            <div style={{ color: "#6ee7b7", fontSize: 10, marginTop: 4 }}>
              {(maxConsecLosses * riskPct) < model.dailyDD * 100
                ? "DD journalier " + (model.dailyDD * 100) + "% INATTEIGNABLE en 1 jour avec cette config"
                : "Attention : serie max " + (maxConsecLosses * riskPct).toFixed(2) + "% > DD jour " + (model.dailyDD * 100) + "%"}
            </div>
          </div>
        </div>
      </div>

      {/* PARAMETRES */}
      <div className="card">
        <div style={{ fontSize: 11, fontWeight: 800, color: "#6ee7b7", marginBottom: 10, textTransform: "uppercase", letterSpacing: 1 }}>Parametres Trading</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          {[
            { label: "Capital ($)", val: capital, set: setCapital, min: 6000, max: 200000, step: 1000 },
            { label: "Risque/trade (%)", val: riskPct, set: setRiskPct, min: 0.05, max: 2, step: 0.05 },
            { label: "Trades/jour", val: tradesPerDay, set: setTradesPerDay, min: 1, max: 15, step: 1 },
            { label: "Objectif/jour (%)", val: dailyTargetPct, set: setDailyTargetPct, min: 0.05, max: 1.5, step: 0.05 },
            { label: "Split (%)", val: split, set: setSplit, min: 80, max: 95, step: 5 },
            { label: "Mois Funded", val: fundedMonths, set: setFundedMonths, min: 1, max: 60, step: 1 },
          ].map((f) => (
            <div key={f.label}>
              <div style={{ fontSize: 10, color: "#64748b", marginBottom: 3, fontWeight: 700 }}>{f.label}</div>
              <input type="number" value={f.val} min={f.min} max={f.max} step={f.step} onChange={e => f.set(parseFloat(e.target.value) || 0)} />
              <input type="range" min={f.min} max={f.max} step={f.step} value={f.val} onChange={e => f.set(parseFloat(e.target.value))} />
            </div>
          ))}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginTop: 10 }}>
          <div style={{ background: "#0a0a14", borderRadius: 8, padding: "8px 10px", fontSize: 11, color: "#fbbf24" }}>
            Risque : <b>{fmt2(riskAmount)}</b>/trade (fixe)
          </div>
          <div style={{ background: "#0a0a14", borderRadius: 8, padding: "8px 10px", fontSize: 11, color: "#6ee7b7" }}>
            Objectif : <b>{fmt2(capital * dailyTarget)}</b>/jour
          </div>
          <div style={{ background: "#0a0a14", borderRadius: 8, padding: "8px 10px", fontSize: 11, color: "#93c5fd", gridColumn: "1 / 3" }}>
            Profit equivalent : <b>{(monthlyTarget * 100).toFixed(1)}% / mois</b> - frais : <b>{fmt(fee)}</b> - RR : <b style={{ color: requiredRR < 1.5 ? "#6ee7b7" : requiredRR < 2.5 ? "#fbbf24" : "#ef4444" }}>1:{requiredRR.toFixed(2)}</b>
          </div>
        </div>
        <button onClick={() => setSeed(s => s + 1)}
          style={{ marginTop: 10, width: "100%", padding: 9, background: "#1e1e2e", border: "1px solid #2d2d3d", borderRadius: 8, color: "#6ee7b7", fontSize: 12, fontWeight: 800, cursor: "pointer" }}>
          Nouvelle simulation
        </button>
        <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
          <button onClick={copyReport}
            style={{ flex: 1, padding: 9, background: copied ? "#062318" : "#6ee7b7", border: copied ? "1px solid #6ee7b7" : "none", borderRadius: 8, color: copied ? "#6ee7b7" : "#080810", fontSize: 12, fontWeight: 800, cursor: "pointer" }}>
            {copied ? "Copie !" : "Copier le rapport"}
          </button>
          <button onClick={printReport}
            style={{ flex: 1, padding: 9, background: "#93c5fd", border: "none", borderRadius: 8, color: "#080810", fontSize: 12, fontWeight: 800, cursor: "pointer" }}>
            Imprimer / PDF
          </button>
        </div>
      </div>

      {/* BILAN FINANCIER NET */}
      {bilan && (
        <div className="card" style={{ borderLeft: "3px solid #fbbf24" }}>
          <div style={{ fontSize: 11, fontWeight: 800, color: "#fbbf24", marginBottom: 10, textTransform: "uppercase", letterSpacing: 1 }}>Bilan Financier Net</div>
          {[
            { label: "Reward challenge (15%)", val: "+" + fmt2(bilan.reward), color: "#6ee7b7" },
            { label: "Payouts funded verses", val: "+" + fmt2(bilan.payout), color: "#6ee7b7" },
            { label: "En attente (non verse)", val: "+" + fmt2(bilan.pending), color: "#94a3b8" },
            { label: "Frais d'achat challenge", val: "-" + fmt2(bilan.fee), color: "#ef4444" },
          ].map(k => (
            <div key={k.label} className="row">
              <span style={{ color: "#64748b" }}>{k.label}</span>
              <span style={{ color: k.color, fontWeight: 700 }}>{k.val}</span>
            </div>
          ))}
          <div style={{ display: "flex", justifyContent: "space-between", paddingTop: 10, marginTop: 4, borderTop: "1px solid #2d2d3d" }}>
            <span style={{ fontWeight: 800, fontSize: 13 }}>RESULTAT NET</span>
            <span style={{ fontWeight: 800, fontSize: 16, color: bilan.net >= 0 ? "#6ee7b7" : "#ef4444" }}>{fmt2(bilan.net)}</span>
          </div>
        </div>
      )}

      {/* REGLES */}
      <div className="card" style={{ borderLeft: "3px solid #6ee7b7" }}>
        <div style={{ fontSize: 11, fontWeight: 800, color: "#6ee7b7", marginBottom: 8, textTransform: "uppercase", letterSpacing: 1 }}>Regles {model.name}</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr" }}>
          {[
            ...model.phases.map(ph => [ph.label + " objectif", "+" + (ph.target * 100) + "%"]),
            ["DD Journalier", (model.dailyDD * 100) + "% (intraday)"],
            ["DD Total", (model.totalDD * 100) + "% max"],
            ["Limite de temps", "Aucune"],
            ["Min jours/phase", model.phases[0].minDays + " jours"],
            ["Reward challenge", (model.challengeReward * 100) + "%"],
            ["1er payout", "apres " + model.firstPayoutDays + "j"],
            ["Split Funded", "80-90%"],
            ["EA/Algo", "Autorise"],
          ].map((kv) => (
            <div key={kv[0]} className="row">
              <span style={{ color: "#64748b", fontSize: 11 }}>{kv[0]}</span>
              <span style={{ color: "#e2e8f0", fontWeight: 700, fontSize: 11 }}>{kv[1]}</span>
            </div>
          ))}
        </div>
      </div>

      {/* TABS */}
      <div style={{ display: "flex", gap: 6, marginBottom: 12, flexWrap: "wrap" }}>
        {[{ id: "challenge", label: "Challenge" }, { id: "funded", label: "Funded" }, { id: "montecarlo", label: "Monte Carlo" }]
          .map(t => <button key={t.id} className={"tab-btn " + (tab === t.id ? "on" : "off")} onClick={() => setTab(t.id)}>{t.label}</button>)}
      </div>

      {!rrValid && (
        <div className="card" style={{ textAlign: "center", padding: 24, color: "#ef4444", fontWeight: 700, fontSize: 13 }}>
          Combinaison impossible : winrate trop bas pour cet objectif.<br />
          <span style={{ color: "#64748b", fontWeight: 400, fontSize: 12 }}>Monte le winrate ou baisse l'objectif/jour.</span>
        </div>
      )}

      {/* TAB CHALLENGE */}
      {tab === "challenge" && sim && (
        <div>
          {model.phases.map((ph, i) => {
            const data = sim.phaseResults[i];
            const color = i === 0 ? "#6ee7b7" : "#93c5fd";
            return (
              <div className="card" key={i}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                  <div style={{ fontWeight: 800, fontSize: 14 }}>{ph.label} - Objectif +{(ph.target * 100)}%</div>
                  {data ? (
                    <span className="tag" style={{ background: phaseIcon(data.status).bg, color: phaseIcon(data.status).color }}>
                      {phaseIcon(data.status).icon} {phaseIcon(data.status).label}
                    </span>
                  ) : (
                    <span className="tag" style={{ background: "#111118", color: "#64748b", border: "1px solid #1e1e2e" }}>VERROUILLE</span>
                  )}
                </div>
                {data ? (
                  <>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 6, marginBottom: 10 }}>
                      <div className="kpi">
                        <div style={{ fontSize: 9, color: "#64748b" }}>Jours</div>
                        <div style={{ fontSize: 14, fontWeight: 800, color }}>{data.tradingDays}</div>
                      </div>
                      <div className="kpi">
                        <div style={{ fontSize: 9, color: "#64748b" }}>Profit</div>
                        <div style={{ fontSize: 14, fontWeight: 800, color: data.profit >= ph.target ? "#6ee7b7" : data.profit >= 0 ? "#fbbf24" : "#ef4444" }}>
                          {fmtPn(data.profit)}
                        </div>
                      </div>
                      <div className="kpi">
                        <div style={{ fontSize: 9, color: "#64748b" }}>WR trades</div>
                        <div style={{ fontSize: 14, fontWeight: 800, color: "#93c5fd" }}>{data.tradeWinrate.toFixed(0)}%</div>
                      </div>
                      <div className="kpi">
                        <div style={{ fontSize: 9, color: "#64748b" }}>Equity</div>
                        <div style={{ fontSize: 12, fontWeight: 800, color: "#e2e8f0" }}>{fmt(data.finalEquity)}</div>
                      </div>
                    </div>
                    <div style={{ fontSize: 10, color: "#64748b", marginBottom: 8 }}>
                      {data.totalWins} gagnants / {data.totalLosses} perdants - WR jours {data.dayWinrate.toFixed(0)}%
                    </div>
                    {failReason(data.status) && (
                      <div style={{ background: data.status === "running_ok" ? "#2d1f08" : "#2d0808", border: "1px solid " + (data.status === "running_ok" ? "#fbbf2440" : "#ef444440"), borderRadius: 8, padding: 10, fontSize: 12, color: data.status === "running_ok" ? "#fbbf24" : "#fca5a5", marginBottom: 10 }}>
                        {failReason(data.status)}
                      </div>
                    )}
                    <ResponsiveContainer width="100%" height={150}>
                      <AreaChart data={data.days}>
                        <defs>
                          <linearGradient id={"gp" + i} x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor={color} stopOpacity={0.25} />
                            <stop offset="100%" stopColor={color} stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1a1a28" />
                        <XAxis dataKey="day" tick={{ fontSize: 9, fill: "#475569" }} tickFormatter={v => "J" + v} />
                        <YAxis tick={{ fontSize: 9, fill: "#475569" }} tickFormatter={v => "$" + (v / 1000).toFixed(1) + "k"} domain={["auto", "auto"]} />
                        <Tooltip formatter={v => fmt(v)} contentStyle={{ background: "#111118", border: "1px solid #1e1e2e", borderRadius: 8, fontSize: 11 }} />
                        <ReferenceLine y={capital * (1 + ph.target)} stroke={color} strokeDasharray="4 2" />
                        <ReferenceLine y={capital * (1 - model.totalDD)} stroke="#ef4444" strokeDasharray="4 2" />
                        <Area type="monotone" dataKey="equity" stroke={color} strokeWidth={2} fill={"url(#gp" + i + ")"} dot={false} name="Equity" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </>
                ) : (
                  <div style={{ textAlign: "center", padding: "20px 0", color: "#64748b", fontSize: 13 }}>
                    Passe la phase precedente pour debloquer
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* TAB FUNDED */}
      {tab === "funded" && sim && (
        sim.funded ? (
          <>
            <div className="card">
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                <div style={{ fontWeight: 800, fontSize: 14 }}>Compte Funded - {fundedMonths} mois</div>
                <span className="tag" style={{ background: sim.funded.status === "active" ? "#062318" : "#2d0808", color: sim.funded.status === "active" ? "#6ee7b7" : "#ef4444" }}>
                  {sim.funded.status === "active" ? "ACTIF" : "FERME"}
                </span>
              </div>
              <div style={{ background: "#062318", border: "1px solid #6ee7b730", borderRadius: 8, padding: 8, marginBottom: 12, fontSize: 11, color: "#6ee7b7" }}>
                Capital funded = {fmt(capital)} (remis a l'initial) - Seuil retrait : $50 - Payout bi-weekly (14j)
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 12 }}>
                {[
                  { label: "Capital final", val: fmt(sim.funded.finalEquity), color: "#6ee7b7" },
                  { label: "Payout verse", val: fmt(sim.funded.cumulPayout), color: "#fbbf24" },
                  { label: "En attente", val: fmt2(sim.funded.pendingPayout), color: "#94a3b8" },
                  { label: "WR mensuel", val: sim.funded.winrateMonth.toFixed(0) + "%", color: sim.funded.winrateMonth >= 60 ? "#6ee7b7" : "#fbbf24" },
                  { label: "Scaling", val: sim.funded.scalingCount + "x (+40%)", color: "#93c5fd" },
                  { label: "Split final", val: sim.funded.finalSplit + "%", color: sim.funded.finalSplit >= 90 ? "#6ee7b7" : "#fbbf24" },
                ].map((k) => (
                  <div key={k.label} className="kpi">
                    <div style={{ fontSize: 9, color: "#64748b" }}>{k.label}</div>
                    <div style={{ fontSize: 13, fontWeight: 800, color: k.color, marginTop: 2 }}>{k.val}</div>
                  </div>
                ))}
              </div>
              <ResponsiveContainer width="100%" height={180}>
                <ComposedChart data={sim.funded.data}>
                  <defs>
                    <linearGradient id="gfunded" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#6ee7b7" stopOpacity={0.25} />
                      <stop offset="100%" stopColor="#6ee7b7" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1a1a28" />
                  <XAxis dataKey="month" tick={{ fontSize: 9, fill: "#475569" }} tickFormatter={v => "M" + v} />
                  <YAxis tick={{ fontSize: 9, fill: "#475569" }} tickFormatter={v => "$" + (v / 1000).toFixed(0) + "k"} domain={["auto", "auto"]} />
                  <Tooltip formatter={v => fmt(v)} contentStyle={{ background: "#111118", border: "1px solid #1e1e2e", borderRadius: 8, fontSize: 11 }} />
                  <ReferenceLine y={capital} stroke="#475569" strokeDasharray="4 2" />
                  <Area type="monotone" dataKey="equity" stroke="#6ee7b7" strokeWidth={2} fill="url(#gfunded)" dot={false} name="Equity" />
                  <Line type="monotone" dataKey="cumul" stroke="#fbbf24" strokeWidth={2} dot={false} name="Payout Cumule" />
                </ComposedChart>
              </ResponsiveContainer>
            </div>

            <div className="card">
              <div style={{ fontWeight: 800, fontSize: 13, marginBottom: 10, color: "#fbbf24" }}>Detail Mensuel</div>
              <div style={{ overflowY: "auto", maxHeight: 300 }}>
                <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 11 }}>
                  <thead>
                    <tr style={{ borderBottom: "1px solid #1e1e2e" }}>
                      {["Mois", "Equity", "Profit%", "Payout", "Split", "Streak", "Statut"].map(h => (
                        <th key={h} style={{ padding: "5px 4px", color: "#64748b", textAlign: "right", fontWeight: 700, fontSize: 10 }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {sim.funded.data.map(r => (
                      <tr key={r.month} style={{ borderBottom: "1px solid #0f0f18", background: r.scalingNote ? "#062318" : "transparent" }}>
                        <td style={{ padding: "5px 4px", color: "#94a3b8", textAlign: "right" }}>M{r.month}</td>
                        <td style={{ padding: "5px 4px", color: "#e2e8f0", textAlign: "right" }}>{fmt(r.equity)}</td>
                        <td style={{ padding: "5px 4px", textAlign: "right", color: r.profitPct >= 0 ? "#6ee7b7" : "#ef4444" }}>
                          {(r.profitPct >= 0 ? "+" : "") + r.profitPct.toFixed(2)}%
                        </td>
                        <td style={{ padding: "5px 4px", textAlign: "right", fontWeight: r.payout > 0 ? 700 : 400, color: r.payout > 0 ? "#fbbf24" : "#475569" }}>
                          {r.payout > 0 ? fmt(r.payout) : "-"}
                        </td>
                        <td style={{ padding: "5px 4px", textAlign: "right", color: r.currentSplit >= 90 ? "#6ee7b7" : "#94a3b8" }}>
                          {r.currentSplit}%
                        </td>
                        <td style={{ padding: "5px 4px", textAlign: "right", color: r.streakMonths >= 4 ? "#6ee7b7" : r.streakMonths >= 2 ? "#fbbf24" : "#64748b" }}>
                          {r.streakMonths}/4{r.scalingNote ? " \u{1F4C8}" : ""}
                        </td>
                        <td style={{ padding: "5px 4px", textAlign: "right", fontSize: 12, fontWeight: 700, color: r.status === "active" ? "#6ee7b7" : "#ef4444" }}>
                          {r.status === "active" ? "\u2713" : "\u2717"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        ) : (
          <div className="card" style={{ textAlign: "center", padding: 30 }}>
            <div style={{ color: "#ef4444", fontWeight: 700 }}>Challenge non passe</div>
            <div style={{ color: "#64748b", fontSize: 12, marginTop: 8 }}>Monte le winrate ou reduis le clustering</div>
          </div>
        )
      )}

      {/* TAB MONTE CARLO */}
      {tab === "montecarlo" && rrValid && (
        <MonteCarloTab modelKey={modelKey} capital={capital} p={p} fundedMonths={fundedMonths}
          splitRate={splitRate} winrate={winrate} fee={fee} clusteringPct={clusteringPct} />
      )}

      <div style={{ textAlign: "center", fontSize: 10, color: "#1e1e2e", marginTop: 12, paddingBottom: 8 }}>
        Regles FundedNext Stellar 2026 - Simulation indicative - Pas une garantie
      </div>
    </div>
  );
}

function MonteCarloTab({ modelKey, capital, p, fundedMonths, splitRate, winrate, fee, clusteringPct }) {
  const [results, setResults] = useState(null);
  const model = MODELS[modelKey];

  useEffect(() => {
    const N = 300;
    let failedChallenge = 0, passedChallenge = 0, fundedFailed = 0, fundedActive = 0;
    const netResults = [];
    const maxDDs = [];
    let dd3 = 0, dd5 = 0, dd7 = 0, dd10 = 0;

    for (let i = 0; i < N; i++) {
      let allPassed = true;
      let challengeReward = 0;
      let runMaxDD = 0;
      for (let ph = 0; ph < model.phases.length; ph++) {
        const r = simulatePhase(capital, model.phases[ph], model, p);
        if (r.maxDD > runMaxDD) runMaxDD = r.maxDD;
        if (r.status !== "passed") { allPassed = false; break; }
        if (r.profit > 0) challengeReward += capital * r.profit * model.challengeReward;
      }
      if (!allPassed) { failedChallenge++; netResults.push(-fee); maxDDs.push(runMaxDD); continue; }
      passedChallenge++;
      const funded = simulateFunded(capital, fundedMonths, model, p, splitRate);
      if (funded.maxDD > runMaxDD) runMaxDD = funded.maxDD;
      if (funded.status.startsWith("failed")) fundedFailed++;
      else fundedActive++;
      const net = challengeReward + funded.cumulPayout + funded.pendingPayout - fee;
      netResults.push(net);
      maxDDs.push(runMaxDD);
    }

    maxDDs.forEach(d => {
      if (d >= 3) dd3++;
      if (d >= 5) dd5++;
      if (d >= 7) dd7++;
      if (d >= model.totalDD * 100) dd10++;
    });

    netResults.sort((a, b) => a - b);
    maxDDs.sort((a, b) => a - b);
    const n = netResults.length;
    const profitable = netResults.filter(x => x > 0).length;
    setResults({
      N,
      passRate: +(passedChallenge / N * 100).toFixed(0),
      fundedSurvival: (fundedActive + fundedFailed) > 0 ? +((fundedActive / (fundedActive + fundedFailed)) * 100).toFixed(0) : 0,
      profitableRate: +(profitable / N * 100).toFixed(0),
      netP25: netResults[Math.floor(n * 0.25)],
      netMedian: netResults[Math.floor(n * 0.5)],
      netP75: netResults[Math.floor(n * 0.75)],
      netMax: netResults[n - 1],
      netMin: netResults[0],
      ddMedian: maxDDs[Math.floor(N * 0.5)],
      ddP75: maxDDs[Math.floor(N * 0.75)],
      ddP90: maxDDs[Math.floor(N * 0.9)],
      ddWorst: maxDDs[N - 1],
      dd3Rate: +(dd3 / N * 100).toFixed(0),
      dd5Rate: +(dd5 / N * 100).toFixed(0),
      dd7Rate: +(dd7 / N * 100).toFixed(0),
      dd10Rate: +(dd10 / N * 100).toFixed(0),
      ddLimit: model.totalDD * 100,
      chartData: [
        { name: "Echec Challenge", val: failedChallenge, color: "#ef4444" },
        { name: "Funded OK", val: fundedActive, color: "#6ee7b7" },
        { name: "Funded Ferme", val: fundedFailed, color: "#fbbf24" },
      ],
    });
  }, [modelKey, capital, p.tradesPerDay, p.riskPct, p.rr, p.winrate, p.clustering, fundedMonths, splitRate, fee]);

  if (!results) return <div style={{ padding: 20, textAlign: "center", color: "#64748b" }}>Calcul en cours...</div>;

  return (
    <div>
      <div className="card">
        <div style={{ fontWeight: 800, fontSize: 13, color: "#6ee7b7", marginBottom: 4 }}>{model.name} - {results.N} simulations</div>
        <div style={{ fontSize: 11, color: "#475569", marginBottom: 12 }}>Winrate {winrate}% - clustering {clusteringPct}% - net = reward + payouts - frais</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 14 }}>
          {[
            { label: "Pass Rate Challenge", val: results.passRate + "%", color: results.passRate > 50 ? "#6ee7b7" : results.passRate > 25 ? "#fbbf24" : "#ef4444" },
            { label: "Survie Funded", val: results.fundedSurvival + "%", color: results.fundedSurvival > 70 ? "#6ee7b7" : "#fbbf24" },
            { label: "Runs rentables", val: results.profitableRate + "%", color: results.profitableRate > 60 ? "#6ee7b7" : results.profitableRate > 40 ? "#fbbf24" : "#ef4444" },
            { label: "Resultat net median", val: fmt2(results.netMedian), color: results.netMedian >= 0 ? "#6ee7b7" : "#ef4444" },
          ].map((k) => (
            <div key={k.label} style={{ background: "#0a0a14", borderRadius: 8, padding: 10 }}>
              <div style={{ fontSize: 10, color: "#64748b" }}>{k.label}</div>
              <div style={{ fontSize: 16, fontWeight: 800, color: k.color, marginTop: 2 }}>{k.val}</div>
            </div>
          ))}
        </div>
        <ResponsiveContainer width="100%" height={170}>
          <BarChart data={results.chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1a1a28" />
            <XAxis dataKey="name" tick={{ fontSize: 9, fill: "#475569" }} />
            <YAxis tick={{ fontSize: 9, fill: "#475569" }} />
            <Tooltip contentStyle={{ background: "#111118", border: "1px solid #1e1e2e", borderRadius: 8, fontSize: 11 }} />
            <Bar dataKey="val" name="Simulations" radius={[4, 4, 0, 0]}>
              {results.chartData.map((e, i) => <Cell key={i} fill={e.color} />)}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="card">
        <div style={{ fontWeight: 800, fontSize: 13, color: "#fbbf24", marginBottom: 10 }}>Distribution Resultat Net ({fundedMonths} mois)</div>
        {[
          { label: "Pire cas", val: fmt2(results.netMin), color: "#ef4444" },
          { label: "P25 - Pessimiste", val: fmt2(results.netP25), color: "#f97316" },
          { label: "P50 - Median", val: fmt2(results.netMedian), color: "#fbbf24" },
          { label: "P75 - Optimiste", val: fmt2(results.netP75), color: "#6ee7b7" },
          { label: "Meilleur cas", val: fmt2(results.netMax), color: "#93c5fd" },
        ].map((k) => (
          <div key={k.label} className="row">
            <span style={{ color: "#64748b" }}>{k.label}</span>
            <span style={{ color: k.color, fontWeight: 700 }}>{k.val}</span>
          </div>
        ))}
      </div>

      <div className="card" style={{ borderLeft: "3px solid #ef4444" }}>
        <div style={{ fontWeight: 800, fontSize: 13, color: "#ef4444", marginBottom: 10 }}>Distribution Drawdown sur {results.N} runs</div>
        <div style={{ fontSize: 11, color: "#64748b", marginBottom: 10 }}>
          Profondeur max du DD atteinte au cours de la vie complete (challenge + funded)
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 12 }}>
          {[
            { label: "DD median (P50)", val: results.ddMedian.toFixed(2) + "%", color: "#6ee7b7" },
            { label: "DD P75", val: results.ddP75.toFixed(2) + "%", color: "#fbbf24" },
            { label: "DD P90", val: results.ddP90.toFixed(2) + "%", color: "#f97316" },
            { label: "DD pire run", val: results.ddWorst.toFixed(2) + "%", color: "#ef4444" },
          ].map(k => (
            <div key={k.label} className="kpi">
              <div style={{ fontSize: 9, color: "#64748b" }}>{k.label}</div>
              <div style={{ fontSize: 15, fontWeight: 800, color: k.color }}>{k.val}</div>
            </div>
          ))}
        </div>
        <div style={{ fontSize: 11, fontWeight: 700, color: "#64748b", marginBottom: 6 }}>
          Frequence de depassement des seuils DD
        </div>
        {[
          { label: "Depasse 3%", rate: results.dd3Rate, warning: 50 },
          { label: "Depasse 5%", rate: results.dd5Rate, warning: 30 },
          { label: "Depasse 7%", rate: results.dd7Rate, warning: 20 },
          { label: "Depasse " + results.ddLimit + "% (limite)", rate: results.dd10Rate, warning: 5 },
        ].map(k => (
          <div key={k.label} style={{ marginBottom: 8 }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, marginBottom: 3 }}>
              <span style={{ color: "#64748b" }}>{k.label}</span>
              <span style={{ fontWeight: 800, color: k.rate > k.warning ? "#ef4444" : k.rate > k.warning / 2 ? "#fbbf24" : "#6ee7b7" }}>
                {k.rate}% des runs
              </span>
            </div>
            <div style={{ background: "#1e1e2e", borderRadius: 4, height: 6, overflow: "hidden" }}>
              <div style={{
                height: "100%", borderRadius: 4,
                width: Math.min(100, k.rate) + "%",
                background: k.rate > k.warning ? "#ef4444" : k.rate > k.warning / 2 ? "#fbbf24" : "#6ee7b7"
              }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
